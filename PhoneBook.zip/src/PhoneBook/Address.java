package PhoneBook;

public class Address {

	private String houseNumber;
	private String streetName;
	private String City;
	private String state;
	private String zipCode;

	
	
	public Address(String houseNumber, String streetName, String city, String state, String zipCode) {
		super();
		this.houseNumber = houseNumber;
		this.streetName = streetName;
		this.City = city;
		this.state = state;
		this.zipCode = zipCode;
	
	}
	
	
	public String getHouseNumber() {
		return houseNumber;
	
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	
	}
	public String getStreetName() {
		return streetName;
	
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	
	}
	public String getCity() {
		return City;
	
	}
	public void setCity(String city) {
		City = city;
	
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	
	}
	public String getZipCode() {
		return zipCode;
	
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	
	



}
