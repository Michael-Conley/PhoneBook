package PhoneBook;

public class Person extends Address{

	private String firstName;
	private String middleName;
	private String lastName;	
	private String phoneNumber;

	

	
	public Person(String firstName,String middleName, String lastName, String phoneNumber, String houseNumber, String streetName, String City, String state, String zipCode ) {
		super(houseNumber, streetName, City, state, zipCode);
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.phoneNumber = phoneNumber;
		
	}

	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getPhoneNumbers() {
		return phoneNumber;
	}

	public void setPhoneNumbers(String phoneNumbers) {
		this.phoneNumber = phoneNumbers;
	}

	public String toString(Person[] p) {
		return this.firstName + " " + this.middleName + " " + this.lastName + " " + this.phoneNumber;
	}
}
	













