package PhoneBook;


import java.util.Arrays;
import java.util.Scanner;


public class Menu {
	
	//Person[] phoneBook = new Person[20];
	Person contact1 = new Person("John", " ", "Doe", "6366435698","114", "Market Street", "Saint Louis", "MO" , "63403");
	Person contact2 = new Person("John", "E", "Doe", "8475390126", "324", "Main Street", "Saint Charles", "MO", "63306");
	Person contact3 = new Person("John", "Michael West", "Doe", "5628592375", "547", "Pole ave", "Saint Peters", "MO", "63333");
	Person contact4 = new Person("Robert", " ", "Smith", "6365558989", "545", "cell Street", "Saint Charles", "KS", "63366" );
	Person[] newPersonArray = {contact1, contact2, contact3, contact4};
	
	//main menu start screen
	public void mainMenuScreen() {
		System.out.println("Weclcome to the Phone Book please select from the options below:"
							+ "\n1) To add a new person press the number 1 followed by enter key"
							+ "\n2) To remove a person please press the number 2 followed by enter key"
							+ "\n3) To search the phone book directory please press the number 3 followed by enter key"
							+ "\n4) To update a please press the number 4 followed by enter key"
							+ "\n5) To sort the phone book directory please press the number 5 followed by enter key"
							+ "\n6) To pull up the contact list press 6 followed by enter key"
							+ "\n7) To refresh the main menu press 7 followed by enter key"
							+ "\n8) To exit the menu please press the number 8 followed by enter key");

		Scanner scanner = new Scanner(System.in);
		int userInput= 0; 

		try {
			
			userInput = scanner.nextInt();

		} catch (Exception e) {
			System.out.println("Please enter a number between 1-6: ");
			mainMenuScreen();
		}
		
		
		
		switch (userInput) {
		
		case 1:
			newPersonArray = PhoneBookLogic.addPerson(newPersonArray);
			mainMenuScreen();
			break;
		case 2:			
			newPersonArray = PhoneBookLogic.deletePerson(newPersonArray);
			mainMenuScreen();
			break;
		case 3:
			newPersonArray = PhoneBookLogic.browser(newPersonArray);
			mainMenuScreen();
			break;
		case 4:
			newPersonArray = PhoneBookLogic.updateContact(newPersonArray);
			mainMenuScreen();
			break;
		case 5: 
			newPersonArray = PhoneBookLogic.sort(newPersonArray);
			mainMenuScreen();
			break;
		case 6:
			PhoneBookLogic.ContactList(newPersonArray);
			mainMenuScreen();
			break;	
		case 7:
			mainMenuScreen();
			break;
		
		case 8:
			PhoneBookLogic.exitMenu();			
			break;				

		default:
			System.out.println("Please enter a number between 1-6: ");
			mainMenuScreen();
			
			break;
		}

	}
		

}	

