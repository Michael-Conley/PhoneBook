package PhoneBook;

import java.util.Scanner;


public class PhoneBookLogic {
	
	
	
	public static Person[] addPerson(Person[] newPersonArray) 
	{

		
		
		System.out.println("====Instert the following information=====");

		
		Scanner scanner = new Scanner(System.in);
		int userSelection = 0;
		
		System.out.println("Please enter the first name you wish too add and hit enter: ");
		String firstName = scanner.nextLine();
		
		System.out.println("Please enter the middle name you wish too add and hit enter: ");
		String middleName = scanner.nextLine();
		
		System.out.println("Please enter the last name you wish too add and hit enter: ");		
		String lastName = scanner.nextLine();
		
		System.out.println( "Please enter the phone number you wish too add and hit enter: ");
		String phoneNumber = scanner.nextLine();
		
		System.out.println("Please enter the house number you wish too add and hit enter: ");
		String houseNumber = scanner.nextLine();
		
		System.out.println("Please enter the street name you wish too add and hit enter: ");
		String streetName = scanner.nextLine();
		
		System.out.println("Please enter the full city name you wish too add and hit enter: ");
		String city = scanner.nextLine();
		
		System.out.println("Please enter the 2 letter state abbreviation you wish too add and hit enter: ");
		String state = scanner.nextLine();
		
		System.out.println("Please enter the zip code you wish too add and hit enter: ");
		String zipCode = scanner.nextLine();

		Person newContact = new Person(firstName, middleName, lastName, phoneNumber, houseNumber, streetName, city, state, zipCode);
		Person[] personArray1 = new Person[newPersonArray.length + 1];
		for (int i = 0; i < newPersonArray.length; i++) {
			personArray1[i] = newPersonArray[i];
		}
		personArray1[personArray1.length - 1] = newContact;
		
		
			System.out.println("The contact " + newContact.getFirstName() + ", " + newContact.getMiddleName() + " " + 
					newContact.getLastName() + ", " + newContact.getPhoneNumbers() + ", "+ newContact.getHouseNumber() + ", "
		+ newContact.getStreetName() + ", "+ newContact.getCity() + ", "+ newContact.getState() + ", "+ newContact.getZipCode() + " was added ");
			
		
		return personArray1;
	
	}
	public static Person[] deletePerson(Person[] newPersonArray) 
	{

		System.out.println("Please enter the phone number of the contact you wish to delete: ");

		Scanner delete = new Scanner(System.in);
		String deleteContact = null; 
		int count = 0;

		Person[] inputPersonArray = new Person[newPersonArray.length - 1];
		
		try {
			deleteContact = delete.nextLine();
			
			for (int i = 0; i < newPersonArray.length; i++) 
			{
				if (!newPersonArray[i].getPhoneNumbers().equalsIgnoreCase(deleteContact)) 
				{
					
					inputPersonArray[count] = newPersonArray[i];
					count++;
					
					
				}
				else 			
				{
					System.out.println("This contact was deleted " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ "" + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode()); 
				}
				
				
			}

		} 
		catch (Exception e) 		
		{
			
			System.out.println("Could not find requested contact please try again: ");

			Menu menu = new Menu();
			menu.mainMenuScreen();
		}
		
		
		
		

		return inputPersonArray;
	}
	
	public static Person[] browser(Person[] newPersonArray) {

		
		System.out.println("Please select the method you would like to search for a contact from the list below: "
							+ "\n1)To search by First name press 1"
							+ "\n2)To search by Last name press 2"
							+ "\n3)To search by full name press 3"
							+ "\n4)To search by telephone number 4"
							+ "\n5)To search by City press 5"
							+ "\n6)To search by State press 6"
							+ "\n7)To return to the main menu press 7");
		
		Scanner search = new Scanner(System.in);	
		int searchContact = 0;
		
		
		try {
			searchContact = search.nextInt();
			switch (searchContact) 
			
		{
		
		case 1:
			
			System.out.println("Please enter the first name you wish search for add and hit enter :");
			
			Scanner fName = new Scanner(System.in);
			String  nameFirst= null;
			nameFirst = fName.nextLine();
			int count1 = 0;
			
			
			Person[] searchContactArray1 = new Person[newPersonArray.length];
			try {
				
			for (int i = 0; i < newPersonArray.length; i++) {
				if (newPersonArray[i].getFirstName().equalsIgnoreCase(nameFirst)) 
				{					
				
					searchContactArray1[count1] = newPersonArray[i];
					count1++;	
					System.out.println("The following contact was found: " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode());
				}				 
							
				
			}
				if(count1 == 0) { 
					System.out.println("Contact can not be found");
					browser(newPersonArray);
				
				}
				else {
					browser(newPersonArray);
				}
			}
			
				
			catch (Exception e) 
			{
				
				System.out.println("Contact can not be found");
				browser(newPersonArray);
				
			break;
}
			
		case 2:
			System.out.println("Please enter the last name you wish search for add and hit enter :");
			
			Scanner lName = new Scanner(System.in);
			String  nameLast= null;
			nameLast = lName.nextLine();
			int count2 = 0;
			
			Person[] searchContactArray2 = new Person[newPersonArray.length];
			try {
			for (int i = 0; i < newPersonArray.length; i++) {
				if (newPersonArray[i].getLastName().equalsIgnoreCase(nameLast)) 
				{					
				
					searchContactArray2[count2] = newPersonArray[i];
					count2++;
					System.out.println("The following contacts were found: " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode());
					
		}				 
							
				
			}
				if(count2 == 0) { 
					System.out.println("Contact can not be found");
					browser(newPersonArray);
				
				}
				else {
					browser(newPersonArray);
				}
			}
			
				
			
			catch (Exception e) 
			{
				System.out.println("Contact can not be found");
				browser(newPersonArray);

			break;
			
			}	
		case 3:
			System.out.println("Please enter the contacts Full name in the following order: First name then press enter followed by the last name and enter: ");
			
			Scanner fullName = new Scanner(System.in);
			String  nameFullFirst= null;
			String nameFullLast = null;
			nameFullFirst = fullName.nextLine();
			nameFullLast = fullName.nextLine();
			int count3 = 0;
			
			
			try {
				Person[] searchContactArray3 = new Person[newPersonArray.length];
				for (int i = 0; i < newPersonArray.length; i++) {
				if (newPersonArray[i].getFirstName().equalsIgnoreCase(nameFullFirst) && (newPersonArray[i].getLastName().equalsIgnoreCase(nameFullLast)))
					
					
					{																

					count3++;
					System.out.println("The following contacts were found: " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode());
						
				}				 
				
				
				}
				if(count3==0)
				{
					System.out.println("Contact can not be found");
					browser(newPersonArray);
		
			}
			else 
			{
				browser(newPersonArray);
				
				}
			}
		
			catch (Exception e) 
			{
				System.out.println("Contact can not be found");
				browser(newPersonArray);
			
					
			break;
			}			
		case 4:
			System.out.println("Please enter the telophone number you wish search for and hit enter :");
			
			Scanner tName = new Scanner(System.in);
			String  nameTel= null;
			nameTel = tName.nextLine();
			int count4 = 0;
			
			Person[] searchContactArray4 = new Person[newPersonArray.length];
			try {
			for (int i = 0; i < newPersonArray.length; i++) {
				if (newPersonArray[i].getPhoneNumbers().equalsIgnoreCase(nameTel)) 
				{					
				
					searchContactArray4[count4] = newPersonArray[i];
					count4++;
					System.out.println("The following contacts were found: " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode());
					
		}				 
							
				
			}
				if(count4 == 0) { 
					System.out.println("Contact can not be found");
					browser(newPersonArray);
				
				}
				else {
					browser(newPersonArray);
				}
			}
			
			catch (Exception e) 
			{
				System.out.println("Contact can not be found");
			
				break;
			}
		case 5:
			System.out.println("Please enter the citys full name you wish to search for and hit enter, do not abbrivate: ");
			
			Scanner cityName = new Scanner(System.in);
			String  nameCity= null;
			nameCity = cityName.nextLine();
			int count5 = 0;
			
			Person[] searchContactArray5 = new Person[newPersonArray.length];
			try {
			for (int i = 0; i < newPersonArray.length; i++) {
				if (newPersonArray[i].getCity().equalsIgnoreCase(nameCity)) 
				{					
				
					searchContactArray5[count5] = newPersonArray[i];
					count5++;
					System.out.println("The following contacts were found: " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode());
					
		}				 
							
				
			}
				if(count5 == 0) { 
					System.out.println("Contact can not be found");
					browser(newPersonArray);
				
				}
				else {
					browser(newPersonArray);
				}
			}
			
			catch (Exception e) 
			{
				System.out.println("Contact can not be found");
				browser(newPersonArray);
				break;
			}
		case 6:
			System.out.println("Please enter the contacts 2 letter state abbrivation you wish to search for and hit enter, do not type the full name: ");
			
			Scanner stateName = new Scanner(System.in);
			String  nameState= null;
			nameState = stateName.nextLine();
			int count6 = 0;
			
			Person[] searchContactArray6 = new Person[newPersonArray.length];
			try {
			for (int i = 0; i < newPersonArray.length; i++) {
				if (newPersonArray[i].getState().equalsIgnoreCase(nameState)) 
				{					
				
					searchContactArray6[count6] = newPersonArray[i];
					count6++;
					System.out.println("The following contacts were found: " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
							", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
							+ ", " + newPersonArray[i].getZipCode());
					
		}				 
							
				
			}
				if(count6 == 0) { 
					System.out.println("Contact can not be found");
					browser(newPersonArray);
				
				}
				else {
					browser(newPersonArray);
				}
			}
			
			catch (Exception e) 
			{
				System.out.println("Contact can not be found");
			
				break;
			}
		case 7:
			Menu menu = new Menu();
			menu.mainMenuScreen();
			
			break;
		default:
			System.out.println("Please enter a number between 1-7");
			browser(newPersonArray);
			break;
			}
		}
			catch (Exception e) {
			System.out.println("Please enter a number between 1-7");
			browser(newPersonArray);
		}
		
			

		return newPersonArray;
	}		
	
	
	public static Person[] updateContact(Person[] newPersonArray) 
	{

	System.out.println("Please enter the phone number of the person you wish to update");
	
	
	Scanner update = new Scanner(System.in);
	
	String updateContact = update.nextLine();
	int count = 0;
	
	
	
	
	
	try 
	{
		for (int i = 0; i < newPersonArray.length; i++) 
		{
		if(newPersonArray[i].getPhoneNumbers().equals(updateContact))
		{
		

			

			Scanner updateInfo = new Scanner(System.in);
			
			System.out.println("Please enter the first name you wish to update and hit enter :");
			String firstName = updateInfo.nextLine();
			newPersonArray[i].setFirstName(firstName);
			
			System.out.println("Please enter the middle name you wish to update and hit enter :");
			String middleName = updateInfo.nextLine();
			newPersonArray[i].setMiddleName(middleName);
			
			System.out.println("Please enter the last name you wish to update and hit enter :");		
			String lastName = updateInfo.nextLine();
			newPersonArray[i].setLastName(lastName);
			
			System.out.println("Please enter the Phone Number you wish to update and hit enter :");
			String phoneNumber = updateInfo.nextLine();
			newPersonArray[i].setPhoneNumbers(phoneNumber);
			
			System.out.println("Please enter the house number you wish to update and hit enter :");
			String houseNumber = updateInfo.nextLine();
			newPersonArray[i].setHouseNumber(houseNumber);
			
			System.out.println("Please enter the street name you wish to update and hit enter :");
			String streetName = updateInfo.nextLine();
			newPersonArray[i].setStreetName(streetName);
			
			System.out.println("Please enter the full name of the city you wish to update and hit enter :");
			String city = updateInfo.nextLine();
			newPersonArray[i].setCity(city);
			
			System.out.println("Please enter the state's 2 letter abbreviation you wish to update and hit enter :");
			String state = updateInfo.nextLine();
			newPersonArray[i].setState(state);
			
			System.out.println("Please enter the zip code you wish to update and hit enter :");
			String zipCode = updateInfo.nextLine();
			newPersonArray[i].setZipCode(zipCode);
			

			
			System.out.println("You update this contact with: " + newPersonArray[i].getFirstName() + " , " + newPersonArray[i].getMiddleName() + " , " + 
								newPersonArray[i].getLastName() + " , " + newPersonArray[i].getPhoneNumbers() + " , " + newPersonArray[i].getHouseNumber() + " , " + 
								newPersonArray[i].getStreetName() + " , " + newPersonArray[i].getCity() + " , " + newPersonArray[i].getState() + " , " + newPersonArray[i].getZipCode());
			count++;
			

		}

		}
		if(count == 0) 
			System.out.println("Cound not find contact");
			return newPersonArray;
	
	}
	catch (Exception e) 
	{

		System.out.println("Was not able to find a contact with that phone number please try again: ");
		return newPersonArray;
	}
	}

	public static Person[] sort(Person[] newPersonArray) 
	{
		
		Person tempNumber = new Person(null, null, null, null, null, null, null, null, null); 
		for(int i = 0; i < newPersonArray.length; i++)
		{
			for(int j = i+ 1 ; j < newPersonArray.length; j++)
			{
				if (Long.parseLong(newPersonArray[j].getPhoneNumbers()) < Long.parseLong(newPersonArray[i].getPhoneNumbers()))
				{
					tempNumber = newPersonArray[i];
					newPersonArray[i] = newPersonArray[j];
					newPersonArray[j] = tempNumber;
					
				}
		}
		System.out.println("After sorting : " + newPersonArray[i].getFirstName() + ", " + newPersonArray[i].getMiddleName()+ " " + newPersonArray[i].getLastName()+
				", " + newPersonArray[i].getPhoneNumbers() + ", " + newPersonArray[i].getHouseNumber()+ ", " + newPersonArray[i].getStreetName() + ", " + newPersonArray[i].getCity() + ", " + newPersonArray[i].getState() 
				+ ", " + newPersonArray[i].getZipCode());
		
	}

		return newPersonArray;
	}	
	
	public static void ContactList(Person[] newPersonArray) {	
		
		for (Person contactList : newPersonArray) 
		{

			System.out.println(contactList.getFirstName() + " " + contactList.getMiddleName() + " " + contactList.getLastName() + " " + contactList.getPhoneNumbers() + " " + contactList.getHouseNumber() + " " +
					contactList.getStreetName() + " " + contactList.getCity() + " " + contactList.getState() + " " + contactList.getZipCode() + " ");
		
		}
	}
	
	
	public static void exitMenu() {
		System.out.println("You have exited the program");
		System.exit(0);
	}
	
}














